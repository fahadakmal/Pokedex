export const TOOGLE_FAVOURITE="TOOGLE_FAVOURITE";


export const toggleFavourite=(pokemon)=>({
    type:TOOGLE_FAVOURITE,
    payload:pokemon

})